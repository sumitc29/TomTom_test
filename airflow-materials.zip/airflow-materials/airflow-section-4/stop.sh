#!/bin/bash

# Stop all the containers at once
docker-compose down